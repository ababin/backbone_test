[bbGrid](http://direct-fuel-injection.github.com/bbGrid/)
====================
That's an extendable grid system (jqGrid like) developed on Backbone.js, Twitter Bootstrap and jQuery frameworks.

#### Requirements
- Backbone.js > 1.0.0
- Twitter Bootstrap v3
- jQuery v1.8.3

Include bbGrid.js and bbGrid.css into your project. 
[Documentation and examples.](http://direct-fuel-injection.github.com/bbGrid/)
